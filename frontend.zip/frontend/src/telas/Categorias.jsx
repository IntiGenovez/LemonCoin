export default function Categorias() {
    return <div>página de categorias</div>
}