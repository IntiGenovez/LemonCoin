import Movimentacoes from "../componentes/Movimentacoes";

export default function Despesas() {
    return (<div className="tela-padrao"><Movimentacoes tipo="Despesas" /></div>)
}