export default function Receitas() {
    return ( 
        <div>receitas</div>
    )
}