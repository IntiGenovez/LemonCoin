import { useState } from 'react';
import InputDia from '../componentes/InputDia';
import InputAno from '../componentes/InputAno';

import styles from "../estilos/Cadastro.module.css"

export default function Cadastro(){
    const [nome, setNome] = useState('')
    const [email, setEmail] = useState('')
    const [telefone, setTelefone] = useState('')

    function tratarInput(setVariavel, e) {
        setVariavel(e.target.value)
    }

    return (
        <form className={styles.formulario}>
            <h1>CADASTRE-SE AQUI</h1>
            <input type="text" value={ nome } placeholder='Nome Completo: ' onChange={ e => tratarInput(setNome, e) } />
            <input type="text" value={ email } placeholder='Email: ' onChange={ e => tratarInput(setEmail, e) } />
            <input type="text" value={ telefone } placeholder='Telefone: ' onChange={ e => tratarInput(setTelefone, e) }/>
            
            <div>
                <h2>Data de Nascimento: </h2>
                <div className={styles.inputSelect}>
                    <InputDia />

                    <select name="Mes-nasc" id="Mes-nasc">
                        <option value="">Mês</option>
                        <option value="1">Janeiro</option>
                        <option value="2">Fevereiro</option>
                        <option value="3">Março</option>
                        <option value="4">Abril</option>
                        <option value="5">Maio</option>
                        <option value="6">Junho</option>
                        <option value="7">Julho</option>
                        <option value="8">Agosto</option>
                        <option value="9">Setembro</option>
                        <option value="10">Outubro</option>
                        <option value="11">Novembro</option>
                        <option value="12">Dezembro</option>
                    </select>

                    <InputAno />
                </div>
            </div>
            <div> 
                <h2>Gênero</h2>
                <div className={styles.genero}>
                    <span className={styles.margin} style={{fontWeight: '600'}}>FEMININO <input type='radio' name='Genero' id='GeneroM'></input></span>
                    <span className={styles.margin} style={{fontWeight: '600'}}>MASCULINO <input type='radio' name='Genero' id='GeneroF'></input></span>
                    <span className={styles.margin} style={{fontWeight: '600'}}>OUTRO <input type='radio' name='Genero' id='GeneroF'></input></span>
                </div>
                
                <div className={styles.divSenha}>
                    <h3>Senha</h3>
                    <input type="password" name="Senha" id="Senha" />                
                    <h3>Confirmar Senha</h3>
                    <input type="password" name="Confirm-senha" id="Confirm-senha" />
                    
                </div>
                <button>Cadastrar</button>

            </div>

            
        </form>
    );
}