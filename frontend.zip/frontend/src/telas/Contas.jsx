export default function Contas() {
    return <div>página de contas</div>
}