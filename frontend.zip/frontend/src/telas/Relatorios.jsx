export default function Relatorios() {
    return <div>página de Relatorios</div>
}