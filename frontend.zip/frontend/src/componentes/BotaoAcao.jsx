export default function BotaoAcao({ children }) {
    return (
        <button>{ children }</button>
    )
}